# NDRO Power BI portfolio package v0.2.1

This package contains the canonical desktop and mobile Power BI project for the
SynapSight Neurodegenerative Disease Research Observatory public beta.

## Quick review

- Live public application: <https://synapsight-ndro.streamlit.app/>
- Source repository: <https://github.com/fmelleu/ndro-public-beta>
- Immutable data snapshot: `ndro-mvp-v0.1.2-20260823`
- Snapshot contract: `public-snapshot-v0.1`
- Power BI project: `NDRO_PowerBI_MVP_v0.2.1.pbip`

The package is intentionally distributed as a Power BI Project (`.pbip`) so a
technical reviewer can inspect the report definition, semantic model, Power
Query transformations, DAX measures, relationships and mobile layouts as text.

## Open and refresh

1. Extract the ZIP to `C:\NDRO_PORTFOLIO`.
2. Open `NDRO_PowerBI_MVP_v0.2.1.pbip` in Power BI Desktop.
3. If Power BI asks for a data location, open **Transform data -> Manage
   parameters** and set `SnapshotFolder` to the absolute path of:
   `data\ndro-mvp-v0.1.2-20260823\` inside the extracted package. Preserve the
   final backslash.
4. Select **Close & Apply** and then **Refresh**.

The packaged project uses `C:\NDRO_PORTFOLIO\data\ndro-mvp-v0.1.2-20260823\`
as its neutral default. No personal workstation path is retained.

## What to inspect

The seven public pages form a deliberately different communication layer from
the scientific Streamlit application:

1. **Overview** — headline corpus metrics, status landscape and annual trend.
2. **Disease Trends** — annual and cumulative publication patterns.
3. **Geographic Coverage** — reported country context, top countries and matrix.
4. **Exclusion Analysis** — transparent inclusion and exclusion accounting.
5. **Record Audit** — searchable, row-level provenance for the public snapshot.
6. **Methodology & Data Quality** — snapshot identity, boundaries and QA checks.
7. **Planned Updates** — the versioned analytical roadmap.

Page **99 QA Validation** is an internal desktop-only validation surface.

## Technical highlights

- PBIP source-controlled report and semantic-model definitions.
- Star-like semantic model with explicit relationships and calendar bridge.
- Reusable Power Query contract checks for required columns, snapshot version
  and cutoff-date consistency.
- DAX measures for corpus status, semantic coverage, trends and data quality.
- Seven manually accepted mobile layouts with 49 mobile visual configurations.
- Full disease names in public-facing controls wherever space permits.
- A frozen, checksum-verified public snapshot bundled for reproducible review.
- Read-only analytical design: the Power BI report never accepts community
  audit submissions or writes to the canonical scientific database.

## Reference metrics

| Metric | Value |
|---|---:|
| Candidate associations | 425 |
| Distinct publications | 423 |
| Core associations | 151 |
| Separate-view associations | 15 |
| Excluded associations | 239 |
| Pending associations | 20 |
| Semantically complete associations | 166 |
| Semantic coverage | 89.2% |

## Reproducibility and rights

`PORTFOLIO_PACKAGE.json`, `VALIDATION_REPORT.json` and `SHA256SUMS.csv` document
the package identity and integrity. Application and report source are provided
under Apache License 2.0. NDRO does not relicense titles, abstracts or other
PubMed-derived fields; consult `DATA_LICENSE.md` and `ASSET_AND_LICENSE_NOTES.md`.

The animated preview is a data-driven portfolio walkthrough generated from the
same immutable snapshot. It is not a substitute for opening the authoritative
Power BI project in Power BI Desktop.
