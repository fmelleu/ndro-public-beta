# NDRO Power BI mobile layout

**Updated:** 2026-09-08  
**Phone canvas width:** 324 Power BI layout units  
**Scope:** public pages 01–07; page 99 remains desktop-only because it is an internal QA surface

## Design rules

- Desktop positions and formatting remain unchanged.
- Mobile headers use the compact `SynapSight` name plus the current page name.
- Filters precede the visuals they affect.
- Multi-card visuals use 2 × 2, 1 × 3 or 2 × 3 mobile grids according to their content.
- Charts and tables use the full 324-unit phone width.
- Full disease names remain preferred. Abbreviations deliberately selected in constrained visuals are preserved.
- The transparent `Excluded` navigation target on Overview intentionally overlaps the lower-left card and is placed above it in the mobile z-order.
- The QA page is not part of the public phone experience.

## Page order

1. **Overview:** status, headline cards, corpus breakdown, filters, core trend and candidate landscape.
2. **Disease Trends:** disease/year filters, annual trend, cumulative trend, selected-period comparison and semantic coverage.
3. **Geographic Coverage:** alert, disease filter, metrics, top countries, map and detailed matrix.
4. **Exclusion Analysis:** back navigation, exclusion cards, reasons and disease distribution.
5. **Record Audit:** navigation, filters, filtered count, title/PMID search, clear button and audit table.
6. **Methodology & Data Quality:** snapshot metadata, release status, scientific scope and quality checks.
7. **Planned Updates:** roadmap introduction, phases and release principle.

## Manual acceptance

**Accepted by Fernando Melleu on 2026-09-09.** The desktop and mobile layouts saved in this package are the canonical NDRO Power BI layouts. Future changes must begin from this version and must not silently replace its visual decisions.
