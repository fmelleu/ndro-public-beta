# NDRO Power BI canonical layout

**Status:** Canonical  
**Accepted:** 2026-09-09  
**Accepted by:** Fernando Melleu  
**Scope:** Desktop and mobile layouts

The Power BI Project in this folder is the canonical visual baseline for the NDRO beta. It incorporates the final manual layout corrections made and saved in Power BI Desktop.

## Preservation rules

- Future Power BI work must start from this package.
- Preserve the current desktop and mobile positions, sizing, formatting and navigation unless a change is explicitly approved.
- Use full disease names where space permits; retain abbreviations where the available visual space requires them.
- Keep page 99 as an internal desktop QA surface; pages 01–07 form the public desktop and mobile experience.
- Validate all project JSON and page references before promoting a revised layout.
- Power BI and Streamlit data releases must use the same published snapshot. A layout-only revision does not create a new data snapshot.

## Recovery point

The immediately preceding Power BI package is preserved in:

`90_Archive/Pre_Canonical_PowerBI_Layout_20260909_000551`
